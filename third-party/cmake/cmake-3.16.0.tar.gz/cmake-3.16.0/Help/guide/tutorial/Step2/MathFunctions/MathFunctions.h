double mysqrt(double x);
